package com.example.pillcase;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.content.Intent;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class Login extends AppCompatActivity {
    private Button login;
    EditText log,sign;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        login=(Button)findViewById(R.id.login);
        log=(EditText)findViewById(R.id.editTextPhone2);
        sign=(EditText)findViewById(R.id.editTextTextPassword3);
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(log.getText().toString().equals("9677204028") &&
                        sign.getText().toString().equals("romeo21")) {
                    Intent intent=new Intent(Login.this,Counter.class);
                    startActivity(intent);
                }else{
                    Toast.makeText(getApplicationContext(), "Wrong Credentials",Toast.LENGTH_SHORT).show();
                }
            }

        });
    }
}